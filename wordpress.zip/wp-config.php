<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', 'C:\wamp64\www\wordpress\wp-content\plugins\wp-super-cache/' );
define('DB_NAME', 'Aysha');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'AyshatVirus00');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '6tB>lWpu/e={UhTDtKtS{& rE|Mj}d]ji-xz/qciT]KnPRB6s-Njr$-pocWs4STT');
define('SECURE_AUTH_KEY',  'n]S1%;rnPuveJ2@lZ3<3&TWHG5!Fd%r,7R*a$F1[q|orCZf7yA/NY5yFFVI<lWpg');
define('LOGGED_IN_KEY',    'WLOG}j9+/*H^Ry{*571FEPGFS9WGHm>Q+TeZ*5`m;4ylZmmzT$UXBQ0p8-WHcixp');
define('NONCE_KEY',        'H&QtLiwEG?ucQd4w{tOkx_D|j&2H]TO%R`Nc!yj<Q3C5~avb3Zt=zm~oyV%UpbGn');
define('AUTH_SALT',        'Hy5V ?qCxBRBpR~RmlS ^H8bsj/w#V XMnP^V3Jb;EbBE_,[SofS|Q-HsK7t*;hK');
define('SECURE_AUTH_SALT', 'FM/{*wl]kAf@k|$i;k8Y;[#^ @w.P>k1kkNhRCG>i,/cecxwZ2LP_MhU;T*MJIzK');
define('LOGGED_IN_SALT',   'U1>/<mSci^`Z#<gz7_Y|wA=wQudA313(kiPg+y-1BD=$#Z;)?Xdw_.y/O%7/wuz]');
define('NONCE_SALT',       'b;stU7Gf<~xJa*/qeUaU/Hoa%TA|~I:0@N5W4.L4m1;iNgxGSu%b-0MvqsHuS}TN');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
